#!/usr/bin/env python3
"""
PerfAgents Setup Script
=======================
Automatically installs Node.js (if needed) and sets up the PerfAgents app.
Just run: python setup.py
"""

import subprocess
import sys
import os
import platform
import shutil
import urllib.request
import json

RESET = "\033[0m"
BOLD = "\033[1m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
CYAN = "\033[96m"
BLUE = "\033[94m"

def print_banner():
    print(f"""
{CYAN}{BOLD}
╔══════════════════════════════════════════════════════════╗
║          ⚡ PerfAgents — Setup Script                    ║
║     AI-Powered Performance Testing Hub (16 Agents)       ║
╚══════════════════════════════════════════════════════════╝
{RESET}""")

def step(n, total, msg):
    print(f"\n{BLUE}{BOLD}[{n}/{total}]{RESET} {BOLD}{msg}{RESET}")

def ok(msg):
    print(f"  {GREEN}✓{RESET} {msg}")

def warn(msg):
    print(f"  {YELLOW}⚠{RESET}  {msg}")

def err(msg):
    print(f"  {RED}✗{RESET}  {msg}")

def run(cmd, cwd=None, capture=True):
    result = subprocess.run(
        cmd, shell=True, cwd=cwd,
        stdout=subprocess.PIPE if capture else None,
        stderr=subprocess.PIPE if capture else None,
        text=True
    )
    return result

def check_node():
    result = run("node --version")
    if result.returncode == 0:
        version = result.stdout.strip()
        major = int(version.lstrip('v').split('.')[0])
        return major, version
    return 0, None

def check_npm():
    result = run("npm --version")
    return result.returncode == 0, result.stdout.strip()

def install_node_windows():
    print(f"  {CYAN}Opening Node.js download page for Windows...{RESET}")
    import webbrowser
    webbrowser.open("https://nodejs.org/en/download")
    print(f"""
  {YELLOW}Please:{RESET}
  1. Download and install Node.js LTS from the page that just opened
  2. Run the installer (next → next → install)
  3. RESTART this terminal / VS Code
  4. Run this script again: python setup.py
""")
    sys.exit(0)

def install_node_mac():
    # Try homebrew first
    brew = run("which brew")
    if brew.returncode == 0:
        print(f"  {CYAN}Installing Node.js via Homebrew...{RESET}")
        result = run("brew install node", capture=False)
        if result and result.returncode == 0:
            return True
    # Fallback: open download page
    import webbrowser
    webbrowser.open("https://nodejs.org/en/download")
    print(f"""
  {YELLOW}Homebrew not found. Please:{RESET}
  1. Download and install Node.js LTS from the page that just opened
  2. Restart your terminal
  3. Run: python3 setup.py again
""")
    sys.exit(0)

def install_node_linux():
    print(f"  {CYAN}Installing Node.js via NodeSource...{RESET}")
    cmds = [
        "curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -",
        "sudo apt-get install -y nodejs"
    ]
    for cmd in cmds:
        result = run(cmd, capture=False)
    return True

def main():
    print_banner()
    script_dir = os.path.dirname(os.path.abspath(__file__))
    system = platform.system()
    total_steps = 5

    # ── Step 1: Check Python ──
    step(1, total_steps, "Checking Python version")
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 7):
        err(f"Python 3.7+ required. You have {sys.version}")
        sys.exit(1)
    ok(f"Python {version.major}.{version.minor} — good!")

    # ── Step 2: Check / Install Node.js ──
    step(2, total_steps, "Checking Node.js installation")
    major, node_ver = check_node()

    if major >= 18:
        ok(f"Node.js {node_ver} — perfect!")
    elif major > 0:
        warn(f"Node.js {node_ver} found but version 18+ recommended.")
        warn("Consider upgrading: https://nodejs.org")
    else:
        warn("Node.js not found. Installing...")
        if system == "Windows":
            install_node_windows()
        elif system == "Darwin":
            install_node_mac()
        else:
            install_node_linux()

        # Re-check
        major, node_ver = check_node()
        if major == 0:
            err("Node.js installation failed. Please install manually: https://nodejs.org")
            sys.exit(1)
        ok(f"Node.js {node_ver} installed!")

    # ── Step 3: Check npm ──
    step(3, total_steps, "Checking npm")
    has_npm, npm_ver = check_npm()
    if has_npm:
        ok(f"npm {npm_ver} — ready!")
    else:
        err("npm not found. It should come with Node.js. Try reinstalling Node.")
        sys.exit(1)

    # ── Step 4: Install dependencies ──
    step(4, total_steps, "Installing dependencies (React, Vite)")
    print(f"  {CYAN}Running: npm install  (this takes ~30 seconds first time){RESET}")
    result = run("npm install", cwd=script_dir, capture=False)
    if result and result.returncode != 0:
        err("npm install failed. Check your internet connection.")
        sys.exit(1)
    ok("All dependencies installed!")

    # ── Step 5: Launch ──
    step(5, total_steps, "Launching PerfAgents")
    print(f"""
{GREEN}{BOLD}
  ╔══════════════════════════════════════════════════╗
  ║  🚀 PerfAgents is starting!                      ║
  ║                                                  ║
  ║  → Open your browser to: http://localhost:3000   ║
  ║  → Press Ctrl+C to stop                          ║
  ╚══════════════════════════════════════════════════╝
{RESET}
  {CYAN}Starting development server...{RESET}
""")

    os.chdir(script_dir)
    os.system("npm run dev")

if __name__ == "__main__":
    main()
