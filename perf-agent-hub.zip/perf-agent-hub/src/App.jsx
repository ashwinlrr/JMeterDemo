import { useState, useRef, useEffect, useCallback } from "react";

// ─── ALL AGENTS DEFINITION ────────────────────────────────────────────────────
const AGENTS = [
  {
    id: "script-gen",
    name: "Script Generation",
    short: "ScriptGen",
    icon: "⚡",
    color: "#00FF94",
    category: "PLANNING",
    tagline: "Generate load test scripts from plain English or API specs",
    placeholder: `Describe your API or paste a cURL / OpenAPI spec.

Example:
POST /api/login with 500 concurrent users, ramp over 2 min.
Auth: { "email": "user@test.com", "password": "pass123" }
SLA: p95 < 1s

Preferred tool: k6 / JMeter / Gatling / Locust`,
    systemPrompt: `You are a world-class performance test engineer specializing in load test script generation.
You produce production-ready scripts for k6 (JS), JMeter (JMX XML), Gatling (Scala), and Locust (Python).

Guidelines:
- Infer the best tool if not specified; default to k6
- Include realistic think times (1-3s), ramp-up, and hold phases
- Add proper response checks/assertions
- Parameterize test data (users, endpoints, payloads)
- Add correlation logic where needed (tokens, session IDs)
- Comment all key sections
- Include a quick "How to run" section after the script

Format:
## 📋 What This Tests
## 🛠 Script ([TOOL])
\`\`\`[lang]
...script...
\`\`\`
## ▶️ How to Run
## ⚙️ Key Parameters to Tune`
  },
  {
    id: "test-data-gen",
    name: "Test Data Generation",
    short: "DataGen",
    icon: "🗄️",
    color: "#F59E0B",
    category: "PLANNING",
    tagline: "Generate realistic, parameterized test data for load tests",
    placeholder: `Describe the data you need for your test.

Example:
- 10,000 unique user records (email, password, first/last name)
- Product IDs from 1000 to 9999
- Credit card numbers (test range only)
- Random addresses in US format
- CSV format for k6 or JMeter`,
    systemPrompt: `You are a test data engineer. You generate realistic, production-like test data for performance and load testing.

Guidelines:
- Generate actual sample data (CSV, JSON, SQL inserts, or code)
- Use realistic formats (proper emails, phone numbers, addresses)
- Handle edge cases and boundary values
- Ensure data uniqueness where required
- Provide code (Python/JS) to generate large volumes
- Mask/anonymize any sensitive patterns
- Format output to work directly with k6, JMeter, Gatling, or Locust

Format:
## 📋 Data Plan
## 📊 Sample Data
\`\`\`
...data...
\`\`\`
## 🐍 Generator Script (if volume needed)
## 🔌 How to Load in Your Test Tool`
  },
  {
    id: "workload-model",
    name: "Workload Model Designer",
    short: "Workload",
    icon: "📐",
    color: "#818CF8",
    category: "PLANNING",
    tagline: "Design realistic load profiles from production traffic or business requirements",
    placeholder: `Provide production traffic data or business requirements.

Example A (from analytics):
Peak concurrent users: 3,200
Avg session duration: 8 min
Top 5 transactions: Login 15%, Browse 40%, Search 25%, Checkout 12%, Payment 8%
Peak hours: 12-2pm and 6-8pm

Example B (business requirement):
Black Friday launch: 10x normal load
Normal: 500 users, need to support 5,000
Ramp time: 15 minutes`,
    systemPrompt: `You are a capacity planning and performance modeling expert. You design realistic workload models for load tests.

Deliverables:
- Transaction mix (% breakdown of user actions)
- Concurrent user targets with justification
- Ramp-up / steady-state / ramp-down strategy
- Think time recommendations
- Pacing calculations (arrivals/sec, TPS targets)
- Test scenario types needed: Baseline, Stress, Soak, Spike, Breakpoint
- Load profile expressed as code-ready config for k6, JMeter, or Locust

Format:
## 🎯 Workload Summary
## 👥 User Load Targets
## 🔄 Transaction Mix
## ⏱ Test Scenarios (with timings)
## ⚙️ Load Profile Config Snippets
## 📌 Assumptions & Caveats`
  },
  {
    id: "env-readiness",
    name: "Environment Readiness",
    short: "EnvCheck",
    icon: "🔍",
    color: "#34D399",
    category: "PRE-TEST",
    tagline: "Validate your environment is ready before running any load test",
    placeholder: `Describe your test environment and I'll give you a pre-test readiness checklist.

Example:
- App: Spring Boot microservice (3 pods, 2 CPU / 4GB each)
- DB: PostgreSQL RDS db.r5.2xlarge
- Cache: Redis cluster (3 nodes)
- LB: AWS ALB
- Monitoring: Datadog + CloudWatch
- Stubs: WireMock for payment gateway
- Target test: 2000 concurrent users for 30 minutes`,
    systemPrompt: `You are a performance test environment specialist. You create comprehensive pre-test readiness checklists and validation guides.

Cover all layers:
- Application health (endpoints, startup, logs)
- Infrastructure (CPU, memory, disk, network headroom)
- Database (connections, indexes, slow query log enabled)
- Cache (warmup, hit rate baseline)
- Load balancer / network config
- Test tool / injectors (enough agents, network bandwidth)
- Monitoring & observability (are all dashboards ready?)
- Stub / mock services (are they stable and not rate-limited?)
- Data readiness (test data loaded?)
- Baseline metrics collection (pre-test snapshot)

Format:
## ✅ Environment Readiness Checklist
### 🖥 Application Layer
### 🏗 Infrastructure
### 🗄 Database
### 📡 Network / Load Balancer
### 🔬 Monitoring & Observability
### 🧪 Test Tool Setup
## 🚨 Blockers to Resolve Before Testing
## 📸 Baseline Metrics to Capture`
  },
  {
    id: "execution-orchestrator",
    name: "Test Execution Planner",
    short: "Execution",
    icon: "🚀",
    color: "#F97316",
    category: "EXECUTION",
    tagline: "Plan and orchestrate multi-scenario performance test runs",
    placeholder: `Describe your test execution needs.

Example:
- App: E-commerce checkout flow
- Tools: k6 + Grafana
- Scenarios needed: Baseline, Stress, Soak, Spike
- Duration budget: 6 hours total today
- Team: 2 engineers
- CI/CD: GitHub Actions integration needed
- Abort criteria: p95 > 5s or error rate > 5%`,
    systemPrompt: `You are a performance test execution specialist. You create detailed test run plans and execution guides.

Provide:
- Ordered test execution plan (which tests to run, in what sequence, why)
- Timing schedule (start times, durations, gaps between runs)
- Go/No-Go criteria for each test phase
- Abort conditions and thresholds (auto-abort rules)
- CI/CD integration guidance (GitHub Actions / Jenkins / GitLab)
- Team responsibilities and communication checkpoints
- Environment reset procedures between runs
- Data collection and artifact saving plan
- Rollback plan if production-like environment

Format:
## 📅 Execution Schedule
## 🎯 Test Scenarios (ordered)
## ✅ Go / No-Go Gates
## 🛑 Abort Criteria
## 🔄 CI/CD Pipeline Config
## 👥 Team Runbook
## 💾 Artifact & Data Collection Plan`
  },
  {
    id: "realtime-anomaly",
    name: "Real-Time Anomaly Advisor",
    short: "Anomaly",
    icon: "🚨",
    color: "#EF4444",
    category: "EXECUTION",
    tagline: "Interpret live metrics during a test run and detect anomalies instantly",
    placeholder: `Paste live metrics from your running test and I'll analyze them in real-time.

Example (paste every few minutes during your test):
T+5min: TPS=420, Avg=380ms, P95=890ms, P99=1200ms, Errors=0.1%, CPU=45%, Mem=3.1GB
T+10min: TPS=418, Avg=395ms, P95=920ms, P99=1400ms, Errors=0.3%, CPU=52%, Mem=3.4GB
T+15min: TPS=390, Avg=680ms, P95=2100ms, P99=4800ms, Errors=1.2%, CPU=78%, Mem=5.8GB
T+20min: TPS=310, Avg=1450ms, P95=5200ms, P99=9800ms, Errors=4.8%, CPU=94%, Mem=7.1GB`,
    systemPrompt: `You are a real-time performance monitoring expert. You analyze live test metrics and immediately identify anomalies, trends, and risks.

Analyze for:
- Response time trends (gradual degradation vs sudden spike)
- Throughput drops (TPS decrease under same load = saturation)
- Error rate acceleration
- Memory leak signatures (steadily growing memory)
- CPU saturation patterns
- Thread pool exhaustion signals
- GC pressure indicators
- Cascading failure patterns

Severity levels: 🔴 CRITICAL (abort now) | 🟡 WARNING (watch closely) | 🟢 NORMAL

Format:
## ⚡ Live Status: [CRITICAL/WARNING/NORMAL]
## 📈 Trend Analysis
## 🔴 Anomalies Detected
## 🧠 Likely Root Cause
## 🛑 Recommendation (Continue / Throttle / ABORT)
## 👀 Watch These Metrics Next`
  },
  {
    id: "results-analysis",
    name: "Results Analysis",
    short: "Analyzer",
    icon: "🔬",
    color: "#06B6D4",
    category: "ANALYSIS",
    tagline: "Deep analysis of test results — bottlenecks, patterns, root causes",
    placeholder: `Paste your test results in any format.

JMeter CSV, k6 output, Gatling summary, Locust stats, or raw metrics:

Example:
Total Requests: 180,000 | Duration: 30min | Tool: k6
Avg: 1250ms | P50: 800ms | P75: 1400ms | P90: 2800ms | P95: 3800ms | P99: 6200ms
Max: 18400ms | Error Rate: 2.3% | Throughput: 420 req/s
Peak CPU: 87% | Avg CPU: 71% | Memory: 6.2GB / 8GB (peak)
Top Errors: HTTP 503 (timeout) 78%, HTTP 500 12%, Connection refused 10%`,
    systemPrompt: `You are a senior performance engineer and systems analyst with deep expertise in bottleneck identification.

Analyze:
1. Percentile distribution interpretation (P50/P90/P95/P99 spread = contention indicator)
2. Response time patterns: normal, bimodal, long-tail, cliff
3. Error classification and likely causes
4. Throughput vs response time correlation
5. Resource saturation patterns
6. SLA compliance assessment
7. Comparison benchmarks (industry standards where applicable)
8. Severity: 🔴 CRITICAL | 🟡 WARNING | 🟢 OK

Format:
## 📊 Results Summary
## 🎯 SLA Compliance
## 🚨 Issues Detected
## 🔍 Bottleneck Analysis
## 📉 Error Analysis
## ✅ What's Performing Well
## 🛠 Prioritized Recommendations
## 🔬 Suggested Follow-up Tests`
  },
  {
    id: "regression",
    name: "Regression Comparison",
    short: "Regression",
    icon: "📊",
    color: "#A855F7",
    category: "ANALYSIS",
    tagline: "Compare baseline vs current — detect regressions with PASS/FAIL verdict",
    placeholder: `Provide BASELINE and CURRENT results. Label them clearly.

--- BASELINE (v2.1.0 / 2024-01-10) ---
Avg: 450ms | P90: 820ms | P95: 980ms | P99: 1200ms
Error Rate: 0.1% | Throughput: 850 req/s
CPU: 52% | Memory: 3.8GB

--- CURRENT (v2.2.0 / 2024-01-20) ---
Avg: 680ms | P90: 1450ms | P95: 1850ms | P99: 3200ms
Error Rate: 0.8% | Throughput: 790 req/s
CPU: 71% | Memory: 5.1GB`,
    systemPrompt: `You are a performance regression analysis expert. You make clear, defensible go/no-go release decisions.

Analysis approach:
1. Calculate % change per metric
2. Flag: ≥10% degradation = WARNING, ≥25% = CRITICAL, ≥50% = SEVERE
3. Improvements ≥10% = NOTABLE GAIN
4. Assess statistical meaningfulness
5. Consider: Is this regression load-dependent? Data-volume-dependent?
6. Provide a single clear verdict with justification

Verdict options: ✅ PASS | ⚠️ CONDITIONAL PASS | ❌ FAIL

Format:
## 🔄 Metric Comparison Table
| Metric | Baseline | Current | Δ% | Status |

## 🚦 VERDICT: [PASS/CONDITIONAL PASS/FAIL]
**Justification:** ...

## 🔴 Regressions
## 🟢 Improvements
## 🔍 Root Cause Hypotheses
## 📋 Required Actions Before Release
## ⚙️ Suggested CI/CD Threshold Config`
  },
  {
    id: "bottleneck-investigator",
    name: "Bottleneck Investigator",
    short: "Investigator",
    icon: "🕵️",
    color: "#EC4899",
    category: "ANALYSIS",
    tagline: "Correlate APM traces, logs, and metrics to pinpoint root causes",
    placeholder: `Paste any combination of: APM data, thread dumps, GC logs, DB slow queries, error logs, or metrics.

Example:
Symptom: P99 spiked to 8s at 600 users

GC Log snippet:
[GC pause (G1 Evacuation Pause) 5200ms]
[GC pause (G1 Evacuation Pause) 4800ms]

DB Slow Queries:
SELECT * FROM orders WHERE user_id=? AND status='pending' — 3200ms (no index)

Thread Dump: 47 threads BLOCKED on HikariPool-1 connection acquire
Active DB connections: 100/100 (pool exhausted)`,
    systemPrompt: `You are a systems performance detective. You correlate multi-source evidence to identify the definitive root cause of performance issues.

Investigation layers:
- Application: thread pools, connection pools, GC, heap, code-level locks
- Database: slow queries, missing indexes, lock contention, N+1 queries, connection pool exhaustion
- Cache: cold cache, eviction, serialization overhead
- Network: latency, packet loss, DNS, SSL handshake overhead
- Infrastructure: CPU steal time, memory pressure, I/O wait, disk throughput
- Third-party: slow downstream services, timeout misconfiguration

Format:
## 🎯 Root Cause Summary (top 3 most likely)
## 🔍 Evidence Analysis
### Layer: [Application/DB/Cache/Network/Infra]
**Evidence:** ...
**Interpretation:** ...
**Confidence:** High/Medium/Low

## 🛠 Fixes (specific and actionable)
## ✅ Verification Steps (how to confirm fix worked)
## 🔮 Prevention Recommendations`
  },
  {
    id: "report-gen",
    name: "Report Generation",
    short: "Reporter",
    icon: "📝",
    color: "#38BDF8",
    category: "REPORTING",
    tagline: "Generate executive or engineering-grade test reports ready to share",
    placeholder: `Paste test data and specify report type.

Example:
Test: Checkout API Load Test
Date: 2024-01-20 | Version: v2.2.0 | Tool: k6
Load: 1000 concurrent users, 30 min steady state
Environment: AWS us-east-1, 4 pods (4CPU/8GB each)

Results:
Avg: 320ms | P95: 890ms | P99: 1450ms
Error Rate: 0.3% | Throughput: 1240 req/s
Peak CPU: 72% | Memory: 4.1/8GB

Issues Found: Slow DB query on /checkout/validate (~400ms)
Fix Applied: Added composite index

Report Type: Executive Summary / Engineering Detail / Both`,
    systemPrompt: `You are a performance testing consultant who writes professional reports for technical and business audiences.

Executive reports use: business impact language, risk framing, go/no-go recommendations, cost implications.
Engineering reports use: full metrics with percentiles, bottleneck details, config recommendations, test reproducibility info.

Always include:
- Clear pass/fail statement
- SLA compliance table
- Visual ASCII trend charts where helpful
- Prioritized action items with owners
- Professional, ready-to-share formatting

Format:
# 📋 Performance Test Report — [System Name]
**Date:** | **Version:** | **Tester:**

## Executive Summary
## Test Scope & Configuration
## Results Overview
## SLA Compliance
## Key Findings
## Recommendations
## Appendix (raw data)`
  },
  {
    id: "capacity-planning",
    name: "Capacity Planning",
    short: "Capacity",
    icon: "📈",
    color: "#10B981",
    category: "REPORTING",
    tagline: "Model future capacity needs and infrastructure scaling requirements",
    placeholder: `Provide current performance data and growth projections.

Example:
Current State:
- Users: 500 concurrent, response OK at P95=800ms
- Infrastructure: 3 pods (2CPU/4GB), CPU avg 45%, Memory avg 60%
- DB: RDS r5.large, CPU avg 35%

Growth Projections:
- 3 months: 2x current load
- 6 months: 5x (product launch)
- 12 months: 10x

Constraint: Budget for max 2x infrastructure cost`,
    systemPrompt: `You are a capacity planning and cloud architecture expert specializing in performance-driven scaling decisions.

Deliverables:
- Current capacity headroom analysis (how much load can current infra handle?)
- Scaling projections (pods/instances needed at each growth milestone)
- Cost estimates (approximate AWS/GCP/Azure costs)
- Horizontal vs vertical scaling recommendations
- Auto-scaling configuration recommendations
- Database scaling strategy (read replicas, sharding, caching)
- Break-even points and saturation thresholds
- Risk assessment per growth milestone

Format:
## 📊 Current Capacity Analysis
## 📈 Growth Scenarios & Infrastructure Needs
| Milestone | Load | Pods Needed | DB | Est. Cost |

## 🏗 Recommended Architecture Changes
## ⚙️ Auto-Scaling Config
## 💰 Cost Projection
## ⚠️ Risks & Mitigation
## 🗺 Scaling Roadmap`
  },
  {
    id: "sla-monitoring",
    name: "SLA Monitoring Advisor",
    short: "SLA",
    icon: "🎯",
    color: "#FBBF24",
    category: "MONITORING",
    tagline: "Define SLA thresholds, monitor compliance, and detect drift",
    placeholder: `Provide your SLA requirements or current metrics for SLA analysis.

Example:
Service: Payment API
SLA Requirements:
- Availability: 99.9%
- P95 response time: < 1000ms
- P99 response time: < 2000ms
- Error rate: < 0.5%
- Throughput: minimum 500 req/s

Current month metrics (weekly averages):
Week 1: P95=780ms, P99=1200ms, Errors=0.2%, Availability=99.95%
Week 2: P95=820ms, P99=1450ms, Errors=0.3%, Availability=99.92%
Week 3: P95=950ms, P99=1780ms, Errors=0.4%, Availability=99.88%
Week 4: P95=1100ms, P99=2300ms, Errors=0.7%, Availability=99.71%`,
    systemPrompt: `You are an SLA management and observability expert. You track SLA compliance, detect trends, and help teams stay ahead of breaches.

Analysis:
- Current SLA compliance status per metric
- Trend analysis (improving/degrading/stable)
- Breach prediction (at current rate, when will SLA be breached?)
- Error budget calculation and burn rate
- Alerting threshold recommendations
- Monitoring tool configurations (Grafana, Datadog, New Relic)
- SLO vs SLA distinction and recommendations

Format:
## 🎯 SLA Compliance Dashboard
| Metric | Target | Current | Status | Trend |

## 📉 Error Budget Status
## ⚠️ Breach Risk Assessment
## 📊 Trend Analysis
## 🔔 Recommended Alert Thresholds
## 📱 Monitoring Configuration Snippets
## 🛠 Immediate Actions Required`
  },
  {
    id: "chaos-resilience",
    name: "Chaos & Resilience Advisor",
    short: "Chaos",
    icon: "🌪️",
    color: "#FB7185",
    category: "MONITORING",
    tagline: "Design chaos experiments to validate system resilience under failure",
    placeholder: `Describe your system architecture for chaos experiment design.

Example:
Architecture:
- Frontend: React SPA on CloudFront
- API: 4 Spring Boot pods behind ALB
- DB: PostgreSQL primary + 1 read replica (RDS)
- Cache: Redis cluster (3 nodes)
- Queue: SQS + 2 consumer pods
- External: Stripe payment API, SendGrid email

Current resilience gaps suspected:
- No circuit breakers on Stripe calls
- Redis cluster failover untested
- No retry logic on SQS consumers`,
    systemPrompt: `You are a chaos engineering and resilience testing expert (SRE background). You design targeted chaos experiments to expose reliability weaknesses.

For each experiment provide:
- Hypothesis (what we expect to happen)
- Blast radius (what could go wrong if hypothesis is wrong)
- Execution steps (specific commands/tools: Chaos Monkey, Litmus, k6 fault injection, tc netem, kill commands)
- Success criteria (how we know system is resilient)
- Rollback procedure
- Monitoring to watch during experiment

Categories: Network, Compute, Storage, Application, Dependency, Data

Format:
## 🧪 Experiment Plan Overview
## 🔬 Experiment 1: [Name]
**Hypothesis:** | **Risk Level:** Low/Medium/High
**Steps:** | **Success Criteria:** | **Rollback:**

[repeat for each experiment]

## 📋 Prerequisites
## 🗓 Recommended Execution Order
## 🛡 Resilience Improvement Roadmap`
  },
  {
    id: "knowledge-base",
    name: "Knowledge Base",
    short: "KnowledgeBase",
    icon: "🧠",
    color: "#67E8F9",
    category: "UTILITY",
    tagline: "Ask anything about performance testing — concepts, tools, tuning, best practices",
    placeholder: `Ask any performance testing question.

Examples:
- What's the difference between load test, stress test, and soak test?
- How do I tune JVM for high-throughput Java apps?
- Why is my k6 test showing different results than JMeter?
- What does a P99 of 8 seconds mean when P95 is 1 second?
- How do I set up Grafana + InfluxDB with k6?
- What's Little's Law and how do I use it?
- How many virtual users do I need for my load test?
- Explain the coordinated omission problem`,
    systemPrompt: `You are a world-class performance testing expert, author, and educator with 15+ years of experience. You have deep knowledge of:
- Load testing tools: k6, JMeter, Gatling, Locust, Artillery, wrk, ab
- Performance concepts: Little's Law, coordinated omission, USL, Amdahl's Law
- JVM tuning, GC algorithms, heap profiling
- Database performance: query optimization, indexing, connection pooling
- Cloud infrastructure: AWS/GCP/Azure scaling patterns
- APM tools: Datadog, New Relic, Dynatrace, Grafana, Prometheus
- Protocols: HTTP/2, gRPC, WebSockets, async messaging
- Architecture patterns: microservices, caching strategies, CDN

Answer with:
- Clear, accurate explanations
- Practical examples and code snippets where helpful
- Tool-specific guidance
- Common pitfalls to avoid
- Links to key concepts for further reading (mention them, don't hallucinate URLs)

Be the mentor every performance engineer wishes they had.`
  },
  {
    id: "threshold-advisor",
    name: "Threshold & Alert Advisor",
    short: "Thresholds",
    icon: "⚙️",
    color: "#C084FC",
    category: "UTILITY",
    tagline: "Get scientifically-grounded SLA thresholds and CI/CD gate configurations",
    placeholder: `Describe your application and business context.

Example:
Application: B2C e-commerce checkout
Tech stack: Node.js + PostgreSQL + Redis
Deployment: Kubernetes (GKE), 3 zones
User base: 50K DAU, peaks 5x on weekends
Business impact: Each 100ms latency increase = ~1% conversion drop
Competitor benchmarks: checkout P95 ~800ms industry average

Current metrics in prod:
Avg: 280ms, P95: 650ms, P99: 1100ms, Errors: 0.05%

Need: k6 thresholds, Grafana alert rules, CI/CD pass/fail gates`,
    systemPrompt: `You are a performance SRE and threshold-setting expert. You use data-driven approaches to recommend thresholds that balance strictness with stability.

Provide:
- Recommended thresholds per metric (P50, P90, P95, P99, error rate, throughput)
- Business justification for each threshold
- Tiered alerting (warning vs critical vs page)
- k6 threshold config (ready to paste)
- Grafana alert rules (YAML/JSON)
- GitHub Actions / Jenkins CI gate config
- Anti-patterns to avoid (too tight = flaky, too loose = useless)

Format:
## 🎯 Recommended Thresholds
| Metric | Warning | Critical | Page |

## ⚙️ k6 Threshold Config
\`\`\`js
thresholds: { ... }
\`\`\`
## 📊 Grafana Alert Rules
## 🔁 CI/CD Gate Configuration
## 📌 Rationale & Business Context
## ⚠️ Common Threshold Pitfalls`
  },
  {
    id: "test-strategy",
    name: "Test Strategy Advisor",
    short: "Strategy",
    icon: "🗺️",
    color: "#4ADE80",
    category: "PLANNING",
    tagline: "Build a complete performance testing strategy for your project or release",
    placeholder: `Describe your project, team, and goals.

Example:
Project: Fintech lending platform rewrite (monolith → microservices)
Timeline: 3 months to production
Team: 2 perf engineers, 1 DevOps
Release risk: HIGH (financial data, regulatory requirements)
Known concerns: Payment processing latency, DB migration data volume
Tools available: k6, Grafana, Datadog, GitHub Actions
Environments: Dev, Staging, Prod (prod data masked in staging)`,
    systemPrompt: `You are a performance testing strategy consultant. You design comprehensive, practical testing strategies that fit team capacity and project risk levels.

Deliverables:
- Test type selection and justification (which of: baseline, load, stress, soak, spike, volume, endurance)
- Risk-based testing priority matrix
- Test environment strategy
- Entry/exit criteria for each test phase
- Integration with SDLC (when to test in dev, staging, pre-prod)
- CI/CD integration points
- Team skills and tooling recommendations
- Timeline and effort estimates
- Reporting and sign-off process

Format:
## 🗺 Strategy Overview
## 🎯 Test Types & Justification
## 📋 Risk Matrix
| Risk | Likelihood | Impact | Test Coverage |

## ⏱ Testing Timeline & Milestones
## 🔗 CI/CD Integration Plan
## 👥 Team & Skills Plan
## ✅ Entry / Exit Criteria
## 📊 Reporting & Sign-off Process`
  }
];

const CATEGORIES = ["PLANNING", "PRE-TEST", "EXECUTION", "ANALYSIS", "REPORTING", "MONITORING", "UTILITY"];
const CATEGORY_COLORS = {
  PLANNING: "#818CF8",
  "PRE-TEST": "#34D399",
  EXECUTION: "#F97316",
  ANALYSIS: "#06B6D4",
  REPORTING: "#38BDF8",
  MONITORING: "#FBBF24",
  UTILITY: "#C084FC"
};

// ─── TYPING INDICATOR ────────────────────────────────────────────────────────
function TypingIndicator({ color }) {
  return (
    <div style={{ display: "flex", gap: 5, alignItems: "center", padding: "12px 16px" }}>
      {[0, 1, 2].map(i => (
        <span key={i} style={{
          width: 7, height: 7, borderRadius: "50%", display: "block",
          background: color, animation: `bounce 1.2s ease-in-out ${i * 0.18}s infinite`
        }} />
      ))}
    </div>
  );
}

// ─── MESSAGE RENDERER ─────────────────────────────────────────────────────────
function MessageContent({ content }) {
  const [copied, setCopied] = useState(null);
  const copy = (text, id) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  const parts = content.split(/(```[\s\S]*?```)/g);
  return (
    <div>
      {parts.map((part, i) => {
        if (part.startsWith("```")) {
          const lines = part.split("\n");
          const lang = lines[0].replace("```", "").trim() || "code";
          const code = lines.slice(1, -1).join("\n");
          return (
            <div key={i} style={{ margin: "10px 0", borderRadius: 8, overflow: "hidden", border: "1px solid rgba(255,255,255,0.08)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "5px 12px", background: "rgba(0,0,0,0.5)", fontSize: 11, color: "#94a3b8" }}>
                <span style={{ fontFamily: "'JetBrains Mono', monospace" }}>{lang}</span>
                <button onClick={() => copy(code, i)} style={{ background: "none", border: "1px solid rgba(255,255,255,0.15)", color: copied === i ? "#4ADE80" : "#94a3b8", padding: "2px 10px", borderRadius: 4, cursor: "pointer", fontSize: 10, transition: "all 0.2s" }}>
                  {copied === i ? "✓ Copied" : "Copy"}
                </button>
              </div>
              <pre style={{ margin: 0, padding: "14px 16px", background: "rgba(0,0,0,0.35)", overflowX: "auto", fontSize: 12, lineHeight: 1.65, color: "#e2e8f0", fontFamily: "'JetBrains Mono', monospace" }}>
                <code>{code}</code>
              </pre>
            </div>
          );
        }
        return <span key={i} style={{ whiteSpace: "pre-wrap" }}>{part}</span>;
      })}
    </div>
  );
}

// ─── AGENT CHAT ───────────────────────────────────────────────────────────────
function AgentChat({ agent }) {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [tool, setTool] = useState("k6");
  const bottomRef = useRef(null);
  const textRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);

  const send = useCallback(async () => {
    if (!input.trim() || loading) return;
    const userMsg = { role: "user", content: input.trim() };
    const history = [...messages, userMsg];
    setMessages(history);
    setInput("");
    setLoading(true);
    try {
      const toolHint = agent.id === "script-gen" ? `\n\nPreferred tool: ${tool}` : "";
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: agent.systemPrompt + toolHint,
          messages: history.map(m => ({ role: m.role, content: m.content }))
        })
      });
      const data = await res.json();
      const reply = data.content?.map(b => b.text || "").join("") || "⚠️ No response.";
      setMessages([...history, { role: "assistant", content: reply }]);
    } catch {
      setMessages([...history, { role: "assistant", content: "⚠️ Error connecting. Please try again." }]);
    }
    setLoading(false);
  }, [input, loading, messages, agent, tool]);

  const onKey = e => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) send(); };

  const clearChat = () => setMessages([]);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", overflow: "hidden" }}>
      {/* Messages area */}
      <div style={{ flex: 1, overflowY: "auto", padding: "20px", display: "flex", flexDirection: "column", gap: 14 }}>
        {messages.length === 0 ? (
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", gap: 20, textAlign: "center" }}>
            <div style={{ fontSize: 64, filter: "drop-shadow(0 0 30px currentColor)", lineHeight: 1 }}>{agent.icon}</div>
            <div>
              <div style={{ fontSize: 20, fontWeight: 700, color: agent.color, fontFamily: "'Space Grotesk', sans-serif", marginBottom: 8, letterSpacing: "-0.01em" }}>{agent.name}</div>
              <div style={{ fontSize: 13, color: "#64748b", maxWidth: 380, lineHeight: 1.7 }}>{agent.tagline}</div>
            </div>
            <div style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 12, padding: "16px 20px", maxWidth: 420, textAlign: "left" }}>
              <div style={{ fontSize: 10, color: "#475569", fontFamily: "'JetBrains Mono', monospace", marginBottom: 8, letterSpacing: "0.1em" }}>EXAMPLE INPUT</div>
              <div style={{ fontSize: 11.5, color: "#64748b", lineHeight: 1.7, whiteSpace: "pre-wrap" }}>{agent.placeholder.split('\n').slice(0, 6).join('\n')}</div>
            </div>
          </div>
        ) : (
          messages.map((msg, i) => (
            <div key={i} style={{ display: "flex", gap: 10, flexDirection: msg.role === "user" ? "row-reverse" : "row", animation: "fadeUp 0.25s ease" }}>
              <div style={{ width: 30, height: 30, borderRadius: "50%", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13,
                background: msg.role === "user" ? "rgba(255,255,255,0.07)" : `${agent.color}18`,
                border: `1px solid ${msg.role === "user" ? "rgba(255,255,255,0.1)" : agent.color + "35"}`
              }}>
                {msg.role === "user" ? "👤" : agent.icon}
              </div>
              <div style={{
                maxWidth: "80%", padding: "11px 15px", fontSize: 13.5, lineHeight: 1.72, color: "#d4d8e4",
                borderRadius: msg.role === "user" ? "16px 3px 16px 16px" : "3px 16px 16px 16px",
                background: msg.role === "user" ? "rgba(255,255,255,0.05)" : `linear-gradient(135deg, ${agent.color}0f 0%, transparent 100%)`,
                border: `1px solid ${msg.role === "user" ? "rgba(255,255,255,0.08)" : agent.color + "25"}`
              }}>
                <MessageContent content={msg.content} />
              </div>
            </div>
          ))
        )}
        {loading && (
          <div style={{ display: "flex", gap: 10 }}>
            <div style={{ width: 30, height: 30, borderRadius: "50%", background: `${agent.color}18`, border: `1px solid ${agent.color}35`, display: "flex", alignItems: "center", justifyContent: "center" }}>{agent.icon}</div>
            <div style={{ borderRadius: "3px 16px 16px 16px", background: `${agent.color}0f`, border: `1px solid ${agent.color}25` }}>
              <TypingIndicator color={agent.color} />
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Tool selector */}
      {agent.id === "script-gen" && (
        <div style={{ padding: "0 20px 8px", display: "flex", gap: 6, alignItems: "center" }}>
          <span style={{ fontSize: 10, color: "#475569", fontFamily: "'JetBrains Mono', monospace", marginRight: 4 }}>TOOL:</span>
          {["k6", "JMeter", "Gatling", "Locust"].map(t => (
            <button key={t} onClick={() => setTool(t)} style={{
              padding: "3px 12px", borderRadius: 20, fontSize: 11, fontWeight: 600, cursor: "pointer",
              fontFamily: "'JetBrains Mono', monospace", transition: "all 0.15s",
              background: tool === t ? agent.color : "transparent",
              color: tool === t ? "#0a0e1a" : agent.color,
              border: `1px solid ${agent.color}50`
            }}>{t}</button>
          ))}
        </div>
      )}

      {/* Input */}
      <div style={{ padding: "10px 20px 18px", borderTop: "1px solid rgba(255,255,255,0.05)" }}>
        <div style={{ display: "flex", gap: 8, alignItems: "flex-end" }}>
          <textarea ref={textRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={onKey}
            placeholder={agent.placeholder}
            rows={3}
            style={{
              flex: 1, resize: "none", background: "rgba(255,255,255,0.03)",
              border: `1px solid ${input ? agent.color + "55" : "rgba(255,255,255,0.08)"}`,
              borderRadius: 10, padding: "11px 13px", color: "#d4d8e4", fontSize: 13,
              lineHeight: 1.6, outline: "none", fontFamily: "'JetBrains Mono', monospace",
              transition: "border-color 0.2s", scrollbarWidth: "thin"
            }} />
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <button onClick={send} disabled={!input.trim() || loading} style={{
              width: 40, height: 40, borderRadius: 10, border: "none", cursor: "pointer",
              background: input.trim() && !loading ? agent.color : "rgba(255,255,255,0.06)",
              color: input.trim() && !loading ? "#0a0e1a" : "#3f4f6e",
              fontSize: 16, transition: "all 0.18s",
              transform: input.trim() && !loading ? "scale(1.04)" : "scale(1)"
            }}>↑</button>
            {messages.length > 0 && (
              <button onClick={clearChat} title="Clear chat" style={{
                width: 40, height: 40, borderRadius: 10, border: "1px solid rgba(255,255,255,0.06)",
                cursor: "pointer", background: "transparent", color: "#475569", fontSize: 14, transition: "all 0.15s"
              }}>✕</button>
            )}
          </div>
        </div>
        <div style={{ fontSize: 10, color: "#334155", marginTop: 5, paddingLeft: 2, fontFamily: "'JetBrains Mono', monospace" }}>⌘/Ctrl+Enter to send</div>
      </div>
    </div>
  );
}

// ─── SIDEBAR ITEM ─────────────────────────────────────────────────────────────
function SidebarAgent({ agent, active, onClick }) {
  return (
    <button onClick={onClick} style={{
      display: "flex", alignItems: "center", gap: 9, padding: "8px 10px",
      borderRadius: 8, border: "none", cursor: "pointer", textAlign: "left", width: "100%",
      background: active ? `${agent.color}12` : "transparent",
      outline: active ? `1px solid ${agent.color}30` : "1px solid transparent",
      transition: "all 0.15s"
    }}>
      <span style={{ fontSize: 16, lineHeight: 1, flexShrink: 0 }}>{agent.icon}</span>
      <span style={{ fontSize: 11.5, fontWeight: active ? 600 : 400, color: active ? agent.color : "#64748b", transition: "color 0.15s", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontFamily: "'Space Grotesk', sans-serif" }}>{agent.short}</span>
      {active && <span style={{ marginLeft: "auto", width: 5, height: 5, borderRadius: "50%", background: agent.color, flexShrink: 0 }} />}
    </button>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [activeId, setActiveId] = useState("test-strategy");
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const activeAgent = AGENTS.find(a => a.id === activeId);

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html, body, #root { height: 100%; }
        body { background: #080c18; font-family: 'Space Grotesk', sans-serif; -webkit-font-smoothing: antialiased; }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.08); border-radius: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        @keyframes bounce { 0%,100%{transform:translateY(0);opacity:.35} 50%{transform:translateY(-5px);opacity:1} }
        @keyframes fadeUp { from{opacity:0;transform:translateY(6px)} to{opacity:1;transform:translateY(0)} }
        @keyframes glow { 0%,100%{opacity:.3} 50%{opacity:.7} }
        button { font-family: inherit; }
        textarea { font-family: inherit; }
      `}</style>

      <div style={{ height: "100vh", display: "flex", flexDirection: "column", background: "#080c18", color: "#e2e8f0", overflow: "hidden", position: "relative" }}>
        {/* Ambient bg */}
        <div style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
          <div style={{ position: "absolute", top: -300, left: -200, width: 700, height: 700, borderRadius: "50%", background: `radial-gradient(circle, ${activeAgent.color}06 0%, transparent 65%)`, transition: "background 0.6s", animation: "glow 5s ease infinite" }} />
          <div style={{ position: "absolute", bottom: -200, right: -100, width: 500, height: 500, borderRadius: "50%", background: `radial-gradient(circle, ${activeAgent.color}04 0%, transparent 65%)`, animation: "glow 7s ease infinite 2s" }} />
        </div>

        {/* Header */}
        <header style={{ height: 52, flexShrink: 0, borderBottom: "1px solid rgba(255,255,255,0.06)", display: "flex", alignItems: "center", padding: "0 16px", gap: 12, zIndex: 10, background: "rgba(8,12,24,0.85)", backdropFilter: "blur(16px)" }}>
          <button onClick={() => setSidebarOpen(s => !s)} style={{ width: 32, height: 32, borderRadius: 7, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)", cursor: "pointer", color: "#64748b", fontSize: 14, display: "flex", alignItems: "center", justifyContent: "center" }}>
            {sidebarOpen ? "←" : "☰"}
          </button>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div style={{ width: 7, height: 7, borderRadius: "50%", background: activeAgent.color, boxShadow: `0 0 10px ${activeAgent.color}`, animation: "glow 2s infinite", transition: "background 0.4s, box-shadow 0.4s" }} />
            <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12, fontWeight: 500, color: "#94a3b8", letterSpacing: "0.05em" }}>PERF<span style={{ color: activeAgent.color, transition: "color 0.3s" }}>AGENTS</span></span>
          </div>
          <div style={{ height: 20, width: 1, background: "rgba(255,255,255,0.07)" }} />
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: 16 }}>{activeAgent.icon}</span>
            <span style={{ fontSize: 13, fontWeight: 600, color: activeAgent.color, transition: "color 0.3s" }}>{activeAgent.name}</span>
            <span style={{ fontSize: 11, color: "#475569" }}>— {activeAgent.tagline}</span>
          </div>
          <div style={{ marginLeft: "auto", display: "flex", gap: 6, alignItems: "center" }}>
            <div style={{ padding: "3px 10px", borderRadius: 20, background: `${CATEGORY_COLORS[activeAgent.category]}15`, border: `1px solid ${CATEGORY_COLORS[activeAgent.category]}30`, fontSize: 10, color: CATEGORY_COLORS[activeAgent.category], fontFamily: "'JetBrains Mono', monospace", letterSpacing: "0.08em" }}>{activeAgent.category}</div>
            <div style={{ fontSize: 11, color: "#334155", fontFamily: "'JetBrains Mono', monospace" }}>{AGENTS.length} AGENTS</div>
          </div>
        </header>

        <div style={{ flex: 1, display: "flex", overflow: "hidden", zIndex: 1 }}>
          {/* Sidebar */}
          {sidebarOpen && (
            <aside style={{ width: 200, flexShrink: 0, borderRight: "1px solid rgba(255,255,255,0.05)", display: "flex", flexDirection: "column", background: "rgba(255,255,255,0.01)", overflowY: "auto", overflowX: "hidden" }}>
              {CATEGORIES.map(cat => {
                const catAgents = AGENTS.filter(a => a.category === cat);
                if (!catAgents.length) return null;
                return (
                  <div key={cat}>
                    <div style={{ padding: "12px 12px 4px", fontSize: 9, fontFamily: "'JetBrains Mono', monospace", color: CATEGORY_COLORS[cat], letterSpacing: "0.15em", opacity: 0.8 }}>{cat}</div>
                    <div style={{ padding: "0 6px 6px" }}>
                      {catAgents.map(a => (
                        <SidebarAgent key={a.id} agent={a} active={activeId === a.id} onClick={() => setActiveId(a.id)} />
                      ))}
                    </div>
                    <div style={{ height: 1, background: "rgba(255,255,255,0.04)", margin: "0 10px" }} />
                  </div>
                );
              })}
              <div style={{ padding: "12px 12px", marginTop: "auto" }}>
                <div style={{ fontSize: 9, color: "#1e293b", fontFamily: "'JetBrains Mono', monospace", lineHeight: 1.8 }}>
                  Powered by Claude API<br />
                  JMeter · k6 · Gatling · Locust
                </div>
              </div>
            </aside>
          )}

          {/* Chat panel */}
          <main style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }} key={activeId}>
            <AgentChat agent={activeAgent} />
          </main>
        </div>
      </div>
    </>
  );
}
